const SERVER_URL   = 'http://localhost:3001'
const INTERVAL_MS  = 30_000
 
async function poll() {
  try {
    // 1. Fetch leads from server
    const res  = await fetch(`${SERVER_URL}/api/leads`)
    const data = await res.json()
 
    // 2. If empty or no entry, skip
    if (!Array.isArray(data) || data.length === 0) {
      console.log(`[${time()}] No new data.`);
      return
    }
 
    const lead = data[0]
    console.log(`[${time()}] ✅ New lead found:`);
    console.log(JSON.stringify(lead, null, 2));
 
    // TODO: replace console.log above with n8n webhook call when ready
 
    // 3. Delete from server after fetching
    await fetch(`${SERVER_URL}/api/leads`, { method: 'DELETE' });
    console.log(`[${time()}] 🗑️  data.json cleared.`);
 
  } catch (err) {
    console.error(`[${time()}] ❌ Error:`, err.message);
  }
}
 
function time() {
  return new Date().toLocaleTimeString()
}
 
console.log(`🚀 Poller started — checking every ${INTERVAL_MS / 1000}s`);
poll()
setInterval(poll, INTERVAL_MS)